<?php
require_once 'config.php';
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
?>

<?php
$pdo = new PDO("mysql:host=localhost;dbname=petshop", "root", "");
$stmt = $pdo->prepare("SELECT * FROM pets");
$stmt->execute();
$dados = $stmt->fetchAll();
foreach ($dados as $pet) {
    echo $pet['id'] . " - " . $pet['nome'] . "<br>";
}

?>
