<?php
require_once 'config.php';
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
?>

<form action="inserir.php" method="POST">
  
 Animal: <input type="text" name="animal"><br>
 Nome: <input type="text" name="nome" ><br>
 Raça: <input type="text" name="raca" ><br>
 Porte: <input type="text" name="porte" ><br>
 Sexo: <input type="text" name="sexo" ><br>
 Idade: <input type="number" name="idade" ><br>
 Castrado: <input type="text" name="castrado" ><br>
 Observação: <input type="text" name="observacao" >
 <input type="submit" value="Cadastrar">
</form>