<?php
$pdo = new PDO("mysql:host=localhost;dbname=petshop", "root", "");

$animal = $_POST['animal'];
$nome = $_POST['nome'];
$idade = $_POST['idade'];
$porte = $_POST['porte'];
$raca = $_POST['raca'];
$observacao = $_POST['observacao'];
$castrado = $_POST['castrado'];
$sexo = $_POST['sexo'];

$stmt = $pdo->prepare("INSERT INTO pets (animal, nome, idade,porte, raca, observacao, castrado, sexo ) VALUES (:animal, :nome, :idade, :porte, :raca, :observacao, :castrado, :sexo)");
$stmt->bindParam(':animal', $animal);
$stmt->bindParam(':nome', $nome);
$stmt->bindParam(':idade', $idade);
$stmt->bindParam(':porte', $porte);
$stmt->bindParam(':raca', $raca);
$stmt->bindParam(':observacao', $observacao);
$stmt->bindParam(':castrado', $castrado);
$stmt->bindParam(':sexo', $sexo);

if ($stmt->execute()) {
    echo "Pet cadastrado com sucesso!";
} else {
    echo "Erro ao cadastrar pet.";
}
?>
