<?php
$pdo = new PDO("mysql:host=localhost;dbname=petshop", "root", "");


$stmt = $pdo->prepare("SELECT * FROM pets");
$stmt->execute();
$pets = $stmt->fetchAll();
?>

<h2>Lista de Pets/h2>

<table border="1">
  <tr>
    <th>ID</th>
    <th>Animal</th>
    <th>Nome</th>
    <th>Raça</th>
    <th>Porte</th>
    <th>Idade</th>
    <th>Porte</th>
    <th>Sexo</th>
    <th>Castrado</th>
    <th>Observação</th>
    <th colspan="2">Ações</th>

  </tr>

<?php foreach ($pets as $pet): ?>
  <tr>
    <td><?= $pet['id'] ?></td>
    <td><?= $pet['animal'] ?></td>
    <td><?= $pet['nome'] ?></td>
    <td><?= $pet['raca'] ?></td>
    <td><?= $pet['porte'] ?></td>
    <td><?= $pet['idade'] ?></td>
    <td><?= $pet['sexo'] ?></td>
    <td><?= $pet['castrado'] ?></td>
    <td><?= $pet['observacao'] ?></td>
    <td><a href="editar.php?id=<?= $pet['id'] ?>">Editar</a></td>
    <td><a href="deletar.php?id=<?= $aluno['id'] ?>" onclick="return confirm('Tem certeza que deseja excluir?');">Excluir</a></td>
  </tr>
<?php endforeach; ?>

</table>
