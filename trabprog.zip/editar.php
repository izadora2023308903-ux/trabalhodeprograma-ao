<?php
$pdo = new PDO("mysql:host=localhost;dbname=petshop", "root", "");

if (!isset($_GET['id'])) {
    echo "ID não informado.";
    exit;
}

$id = $_GET['id'];

$stmt = $pdo->prepare("SELECT * FROM pets WHERE id = :id");
$stmt->bindParam(':id', $id);
$stmt->execute();
$pet = $stmt->fetch();

if (!$pet) {
    echo "Pet não encontrado.";
    exit;
}
?>

<h2>Editar Aluno</h2>

<form action="atualizar.php" method="post">
  <input type="hidden" name="id" value="<?= $pet['id'] ?>">
 Animal: <input type="text" name="animal" value="<?= $pet['animal'] ?>"><br>
 Nome: <input type="text" name="nome" value="<?= $pet['nome'] ?>"><br>
 Raça: <input type="text" name="raca" value="<?= $pet['raca'] ?>"><br>
 Porte: <input type="text" name="porte" value="<?= $pet['porte'] ?>"><br>
 Sexo: <input type="text" name="sexo" value="<?= $pet['sexo'] ?>"><br>
 Idade: <input type="number" name="idade" value="<?= $pet['idade'] ?>"><br>
 Castrado: <input type="text" name="castrado" value="<?= $pet['castrado'] ?>"><br>
 Observação: <input type="text" name="observacao" value="<?= $pet['observacao'] ?>"><br>

  <button type="submit">Salvar</button>
</form>
